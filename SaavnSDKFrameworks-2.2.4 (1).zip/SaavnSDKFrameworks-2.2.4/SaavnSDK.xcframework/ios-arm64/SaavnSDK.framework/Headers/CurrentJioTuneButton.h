//
//  CurrentJioTuneButton.h
//  Saavn
//
//  Created by Unmesh Rathod on 01/04/20.
//  Copyright © 2020 Saavn. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CurrentJioTuneButton : UIButton

@end

NS_ASSUME_NONNULL_END
