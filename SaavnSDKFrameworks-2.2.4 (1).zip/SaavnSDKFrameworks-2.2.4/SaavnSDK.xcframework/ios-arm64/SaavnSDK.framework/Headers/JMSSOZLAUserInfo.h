//
//  JMSSOZLAUserInfo.h
//  libJMSSO
//
//  Created by Rishab Bokaria on 04/07/16.
//  Copyright © 2016 Reliance Jio Infocomm Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JMSSOUserInfo.h"

@protocol JMSSOZLAUser <NSObject, JMSSOUser>

@end
