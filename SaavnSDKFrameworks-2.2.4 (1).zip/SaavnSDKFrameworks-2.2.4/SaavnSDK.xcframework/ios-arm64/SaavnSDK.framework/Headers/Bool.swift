//
//  Bool.swift
//  Saavn
//
//  Created by Kautsya Kanu on 08/04/21.
//  Copyright © 2021 Saavn. All rights reserved.
//

extension Bool {
    var string: String {
        return self ? "true" : "false"
    }
}
