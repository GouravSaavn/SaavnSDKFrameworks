//
//  ShareModal.h
//  New Saavn
//
//  Created by Clint Balcom on 2/21/18.
//  Copyright © 2018 Saavn. All rights reserved.
//

#import "ModalVC.h"


@interface ShareModal : ModalVC <UICollectionViewDataSource, UICollectionViewDelegate>


@end

