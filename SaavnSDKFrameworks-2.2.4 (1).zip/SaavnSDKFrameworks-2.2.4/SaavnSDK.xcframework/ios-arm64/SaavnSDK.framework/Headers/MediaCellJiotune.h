//
//  MediaCellJiotune.h
//  Saavn
//
//  Created by Kunal Arora on 18/03/20.
//  Copyright © 2020 Saavn. All rights reserved.
//

#import "MediaCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MediaCellJiotune : MediaCell
- (void) setData:(NSDictionary *)data;

@end

NS_ASSUME_NONNULL_END
