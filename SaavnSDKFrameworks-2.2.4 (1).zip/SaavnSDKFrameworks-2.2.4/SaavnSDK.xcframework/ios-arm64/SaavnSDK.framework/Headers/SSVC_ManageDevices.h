//
//  SSVC_ManageDevices.h
//  Saavn
//
//  Created by Clint Balcom on 4/20/18.
//  Copyright © 2018 Saavn. All rights reserved.
//

#import "SettingsSubviewVC.h"


@interface SSVC_ManageDevices : SettingsSubviewVC <MFMailComposeViewControllerDelegate>


@end

